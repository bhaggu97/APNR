# Automatic-Number-Plate-Recognition
Pre-Requisites:
Use it for labeling the images https://github.com/tzutalin/labelImg
Install Jupyter Notebook and Anaconda Command Prompt
Make a folder and run 01_xml_to_csv using Jupyter
Run the second file 02_Object_detection
Then run the third one 03_Prediction.
And then connect with the frontend.
